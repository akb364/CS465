import java.io.*;

public class MsgOpenTransaction implements Serializable
{
    public MsgOpenTransaction()
    {
        // empty
    }
}