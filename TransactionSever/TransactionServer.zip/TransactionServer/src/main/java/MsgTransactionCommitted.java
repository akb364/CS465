import java.io.*;

public class MsgTransactionCommitted implements Serializable
{
    public MsgTransactionCommitted()
    {
        
    }
}